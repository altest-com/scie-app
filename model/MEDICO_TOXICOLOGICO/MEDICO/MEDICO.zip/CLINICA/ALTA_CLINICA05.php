<?php
header("Content-type: text/html; charset=utf8");
require("../../../conexion.php");
include_once "../ConexionBD.php"; 

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];
$ALCOHOLISMO = $_REQUEST['ALCOHOLISMO'];
$EDAD_INICIO_A = $_REQUEST['EDAD_INICIO_A'];
$CONSUMO_S_A = $_REQUEST['CONSUMO_S_A'];
$QUE_CONSUME_A = $_REQUEST['QUE_CONSUME_A'];
$FECHA_A = $_REQUEST['FECHA_A'];
$RIESGO_A = $_REQUEST['RIESGO_A'];
$TABAQUISMO = $_REQUEST['TABAQUISMO'];
$EDAD_INICIO_T = $_REQUEST['EDAD_INICIO_T'];
$CONSUMO_S_T = $_REQUEST['CONSUMO_S_T'];
$QUE_CONSUME_T = $_REQUEST['QUE_CONSUME_T'];
$RIESGO_T = $_REQUEST['RIESGO_T'];
$DROGAS = $_REQUEST['DROGAS'];
$OBSERVACIONES = $_REQUEST['OBSERVACIONES'];


/*"INSERT INTO ASISTENCIA VALUES ('$ID_CANDIDATO', '$ID_EVALUACION', '$NOMBRE','$PRUEBA' ,'$FECHA', '$ASISTENCIA')"*/
		$cone = conectarBD();
		$lol = Verificar_clinica05($cone,$ID_CANDIDATO, $ID_EVALUACION);
		echo $lol;
		$conexion->set_charset("utf8");

		if($lol=="correcto"){
			
			$sqlUpdate = "UPDATE medico_clinica05 SET ALCOHOLISMO = '$ALCOHOLISMO', EDAD_INICIO_A = '$EDAD_INICIO_A', CONSUMO_S_A = '$CONSUMO_S_A', QUE_CONSUME_A = '$QUE_CONSUME_A', FECHA_A = '$FECHA_A',RIESGO_A  = '$RIESGO_A', TABAQUISMO = '$TABAQUISMO',EDAD_INICIO_T='$EDAD_INICIO_T',CONSUMO_S_T='$CONSUMO_S_T',QUE_CONSUME_T='$QUE_CONSUME_T',RIESGO_T='$RIESGO_T',DROGAS='$DROGAS',OBSERVACIONES='$OBSERVACIONES' WHERE ID_CANDIDATO = '$ID_CANDIDATO' AND ID_EVALUACION = '$ID_EVALUACION'";
			if ($conexion->query($sqlUpdate) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
			
		}

		else{
			$sqlInsert = "INSERT INTO medico_clinica05 VALUES ('$ID_CANDIDATO','$ID_EVALUACION','$ALCOHOLISMO','$EDAD_INICIO_A','$CONSUMO_S_A','$QUE_CONSUME_A','$FECHA_A','$RIESGO_A', '$TABAQUISMO', '$EDAD_INICIO_T','$CONSUMO_S_T' ,'$QUE_CONSUME_T', '$RIESGO_T', '$DROGAS', '$OBSERVACIONES')";

			if ($conexion->query($sqlInsert) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
		}
		

$conexion->close();

?>