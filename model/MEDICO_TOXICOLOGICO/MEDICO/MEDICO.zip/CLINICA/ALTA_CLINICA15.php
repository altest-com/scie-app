<?php
header("Content-type: text/html; charset=utf8");
require("../../../conexion.php");
include_once "../ConexionBD.php"; 

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];
$BIOMETRIA = $_REQUEST['BIOMETRIA'];
$QUIMICA_SANGUINEA = $_REQUEST['QUIMICA_SANGUINEA'];
$EXAMEN_ORINA = $_REQUEST['EXAMEN_ORINA'];
$OTRAS_B = $_REQUEST['OTRAS_B'];
$OTRAS_Q = $_REQUEST['OTRAS_Q'];
$OTRAS_E = $_REQUEST['OTRAS_E'];
$GRUPO_SANGUINEO = $_REQUEST['GRUPO_SANGUINEO'];
$RAYOS_X = $_REQUEST['RAYOS_X'];
$DIAGNOSTICO = $_REQUEST['DIAGNOSTICO'];
$RECOMENDACIONES = $_REQUEST['RECOMENDACIONES'];
$CEDULA = $_REQUEST['CEDULA'];


/*"INSERT INTO ASISTENCIA VALUES ('$ID_CANDIDATO', '$ID_EVALUACION', '$NOMBRE','$PRUEBA' ,'$FECHA', '$ASISTENCIA')"*/
		$cone = conectarBD();
		$lol = Verificar_clinica15($cone,$ID_CANDIDATO, $ID_EVALUACION);
		echo $lol;
		$conexion->set_charset("utf8");

		if($lol=="correcto"){
			$sqlUpdate = "UPDATE medico_clinica15 SET BIOMETRIA = '$BIOMETRIA',QUIMICA_SANGUINEA = '$QUIMICA_SANGUINEA', EXAMEN_ORINA = '$EXAMEN_ORINA', OTRAS_B = '$OTRAS_B', OTRAS_Q = '$OTRAS_Q', OTRAS_E = '$OTRAS_E', GRUPO_SANGUINEO = '$GRUPO_SANGUINEO', RAYOS_X = '$RAYOS_X',DIAGNOSTICO='$DIAGNOSTICO',RECOMENDACIONES='$RECOMENDACIONES',CEDULA='$CEDULA' WHERE ID_CANDIDATO = '$ID_CANDIDATO' AND ID_EVALUACION ='$ID_EVALUACION'";
			if ($conexion->query($sqlUpdate) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
			
		}

		else{
			$sqlInsert = "INSERT INTO medico_clinica15 VALUES ('$ID_CANDIDATO','$ID_EVALUACION','$BIOMETRIA','$QUIMICA_SANGUINEA', '$EXAMEN_ORINA', '$OTRAS_B', '$OTRAS_Q','$OTRAS_E' ,'$GRUPO_SANGUINEO', '$RAYOS_X', '$DIAGNOSTICO', '$RECOMENDACIONES', '$CEDULA')";

			if ($conexion->query($sqlInsert) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
		}
		

$conexion->close();

?>