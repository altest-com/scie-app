<?php
header("Content-type: text/html; charset=utf8");
require("../../../conexion.php");
include_once "../ConexionBD.php"; 

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];
$ENFERMEDADES = $_REQUEST['ENFERMEDADES'];
$OTRAS1 = $_REQUEST['OTRAS1'];
$OTRAS2 = $_REQUEST['OTRAS2'];
$OTRAS3 = $_REQUEST['OTRAS3'];
$OTRAS4 = $_REQUEST['OTRAS4'];
$OTRAS5 = $_REQUEST['OTRAS5'];
$MENARCA = $_REQUEST['MENARCA'];
$ESTATUS = $_REQUEST['ESTATUS'];
$CUANDO = $_REQUEST['CUANDO'];
$DIAS = $_REQUEST['DIAS'];
$DISMENORREA = $_REQUEST['DISMENORREA'];
$EUMENORREA = $_REQUEST['EUMENORREA'];
$FUM = $_REQUEST['FUM'];
$GESTAS = $_REQUEST['GESTAS'];
$PARTOS = $_REQUEST['PARTOS'];
$CESAREAS = $_REQUEST['CESAREAS'];
$ABORTOS = $_REQUEST['ABORTOS'];
$FUP = $_REQUEST['FUP'];
$IVSA = $_REQUEST['IVSA'];
$PS = $_REQUEST['PS'];
$MPF = $_REQUEST['MPF'];
$PAPANICOLAU = $_REQUEST['PAPANICOLAU'];
$ANTIGENO = $_REQUEST['ANTIGENO'];


/*"INSERT INTO ASISTENCIA VALUES ('$ID_CANDIDATO', '$ID_EVALUACION', '$NOMBRE','$PRUEBA' ,'$FECHA', '$ASISTENCIA')"*/
		$cone = conectarBD();
		$lol = Verificar_clinica07($cone,$ID_CANDIDATO, $ID_EVALUACION);
		echo $lol;
		$conexion->set_charset("utf8");

		if($lol=="correcto"){
			$sqlUpdate = "UPDATE medico_clinica07 SET ENFERMEDADES = '$ENFERMEDADES', OTRAS1 = '$OTRAS1', OTRAS2 = '$OTRAS2', OTRAS3 = '$OTRAS3', OTRAS4 = '$OTRAS4', OTRAS5 = '$OTRAS5',MENARCA='$MENARCA',ESTATUS='$ESTATUS',CUANDO='$CUANDO',DIAS='$DIAS',DISMENORREA='$DISMENORREA',EUMENORREA='$EUMENORREA',FUM='$FUM',GESTAS='$GESTAS',PARTOS='$PARTOS',CESAREAS='$CESAREAS',ABORTOS='$ABORTOS',FUP='$FUP',IVSA='$IVSA',PS='$PS',MPF='$MPF',PAPANICOLAU='$PAPANICOLAU',ANTIGENO='$ANTIGENO' WHERE ID_CANDIDATO = '$ID_CANDIDATO' AND ID_EVALUACION ='$ID_EVALUACION'";
			if ($conexion->query($sqlUpdate) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
			
		}

		else{
			$sqlInsert = "INSERT INTO medico_clinica07 VALUES ('$ID_CANDIDATO','$ID_EVALUACION','$ENFERMEDADES', '$OTRAS1', '$OTRAS2','$OTRAS3' ,'$OTRAS4', '$OTRAS5', '$MENARCA', '$ESTATUS', '$CUANDO', '$DIAS', '$DISMENORREA', '$EUMENORREA', '$FUM', '$GESTAS', '$PARTOS', '$CESAREAS', '$ABORTOS', '$FUP', '$IVSA', '$PS', '$MPF', '$PAPANICOLAU', '$ANTIGENO')";

			if ($conexion->query($sqlInsert) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
		}
		

$conexion->close();

?>