<?php
include_once "ConexionBD.php";

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];
	
		$cone = conectarBD();
		$lol = contar_fotos($cone,$ID_CANDIDATO, $ID_EVALUACION);
		

		if($lol==0){
			echo "incorrecto";
		}
		elseif ($lol>=5) {
			echo "maximo";
		}
		else{
			echo "correcto";
		}
	
?>