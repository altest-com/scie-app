<?php
header("Content-type: text/html; charset=utf8");
require("../../../conexion.php");
include_once "../ConexionBD.php"; 

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];
$COLOR_ASPECTO = $_REQUEST['COLOR_ASPECTO'];
$GLUCOSA = $_REQUEST['GLUCOSA'];
$BILIRRUBINA = $_REQUEST['BILIRRUBINA'];
$CETONAS = $_REQUEST['CETONAS'];
$DENSIDAD = $_REQUEST['DENSIDAD'];
$SANGRE = $_REQUEST['SANGRE'];
$PH = $_REQUEST['PH'];
$PROTONES = $_REQUEST['PROTONES'];
$UROBILINOGENO = $_REQUEST['UROBILINOGENO'];
$NITRITOS = $_REQUEST['NITRITOS'];
$LEUCOCITOS = $_REQUEST['LEUCOCITOS'];


/*"INSERT INTO ASISTENCIA VALUES ('$ID_CANDIDATO', '$ID_EVALUACION', '$NOMBRE','$PRUEBA' ,'$FECHA', '$ASISTENCIA')"*/
		$cone = conectarBD();
		$lol = Verificar_bitacora3($cone,$ID_CANDIDATO, $ID_EVALUACION);
		echo $lol;
		$conexion->set_charset("utf8");

		if($lol=="correcto"){
			$sqlUpdate = "UPDATE medico_bitacora3 SET COLOR_ASPECTO = '$COLOR_ASPECTO', GLUCOSA = '$GLUCOSA', BILIRRUBINA = '$BILIRRUBINA', CETONAS = '$CETONAS', DENSIDAD = '$DENSIDAD', SANGRE = '$SANGRE', PH = '$PH', PROTONES = '$PROTONES', UROBILINOGENO = '$UROBILINOGENO', NITRITOS = '$NITRITOS', LEUCOCITOS = '$LEUCOCITOS' WHERE ID_CANDIDATO = '$ID_CANDIDATO' AND ID_EVALUACION ='$ID_EVALUACION'";
			if ($conexion->query($sqlUpdate) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
			
		}

		else{
			$sqlInsert = "INSERT INTO medico_bitacora3 VALUES ('$ID_CANDIDATO', '$ID_EVALUACION','$GLUCOSA', '$COLOR_ASPECTO' ,'$BILIRRUBINA', '$CETONAS', '$DENSIDAD', '$SANGRE', '$PH', '$PROTONES', '$UROBILINOGENO', '$NITRITOS', '$LEUCOCITOS')";

			if ($conexion->query($sqlInsert) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
		}
		

$conexion->close();

?>