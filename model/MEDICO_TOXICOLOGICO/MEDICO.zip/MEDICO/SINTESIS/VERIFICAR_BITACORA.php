<?php
include_once "../ConexionBD.php";

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];

		$cone = conectarBD();
		$lol = Verificar_sintesis($cone,$ID_CANDIDATO, $ID_EVALUACION);
		
		echo $lol;
?>