<?php
header("Content-type: text/html; charset=utf8");
require("../../../conexion.php");
include_once "../ConexionBD.php"; 

$ID_CANDIDATO = $_REQUEST['ID_CANDIDATO'];
$ID_EVALUACION = $_REQUEST['ID_EVALUACION'];
$GLUCOSA = $_REQUEST['GLUCOSA'];
$UREA = $_REQUEST['UREA'];
$CREATININA = $_REQUEST['CREATININA'];
$ACIDO_URICO = $_REQUEST['ACIDO_URICO'];
$COLESTEROL = $_REQUEST['COLESTEROL'];
$TRIGLICERIDOS = $_REQUEST['TRIGLICERIDOS'];


/*"INSERT INTO ASISTENCIA VALUES ('$ID_CANDIDATO', '$ID_EVALUACION', '$NOMBRE','$PRUEBA' ,'$FECHA', '$ASISTENCIA')"*/
		$cone = conectarBD();
		$lol = Verificar_bitacora2($cone,$ID_CANDIDATO, $ID_EVALUACION);
		echo $lol;
		$conexion->set_charset("utf8");

		if($lol=="correcto"){
			$sqlUpdate = "UPDATE medico_bitacora2 SET GLUCOSA = '$GLUCOSA', UREA = '$UREA', CREATININA = '$CREATININA', ACIDO_URICO = '$ACIDO_URICO', COLESTEROL = '$COLESTEROL', TRIGLICERIDOS = '$TRIGLICERIDOS' WHERE ID_CANDIDATO = '$ID_CANDIDATO' AND ID_EVALUACION ='$ID_EVALUACION'";
			if ($conexion->query($sqlUpdate) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
			
		}

		else{
			$sqlInsert = "INSERT INTO medico_bitacora2 VALUES ('$ID_CANDIDATO', '$ID_EVALUACION', '$GLUCOSA','$UREA' ,'$CREATININA', '$ACIDO_URICO', '$COLESTEROL', '$TRIGLICERIDOS')";

			if ($conexion->query($sqlInsert) === TRUE) {
		   	 	echo "true";
			} 
				else {
		    	echo "false";
					 }
		}
		

$conexion->close();

?>