<?php
header("Content-type: text/html; charset=utf8");
header('Content-type:application/json');
require("../../conexion.php"); 

$FECHA1 = $_REQUEST['FECHA1'];
$FECHA2 = $_REQUEST['FECHA2'];
$lol = $_REQUEST['lol'];

$conexion->set_charset("utf8");



	if ($result = $conexion->query("SELECT CA.PRIMER_NOMBRE,CA.SEGUNDO_NOMBRE,CA.PRIMER_APELLIDO,CA.SEGUNDO_APELLIDO, CA.CURP FROM candidatos CA INNER JOIN evaluacion EV ON CA.ID_CANDIDATO = EV.ID_CANDIDATO INNER JOIN oficios O ON O.ID_CANDIDATO = EV.ID_CANDIDATO AND O.ID_EVALUACION = EV.ID_EVALUACION INNER JOIN reporte_integracion RIn ON RIn.ID_CANDIDATO = EV.ID_CANDIDATO AND RIn.ID_EVALUACION = EV.ID_EVALUACION WHERE EV.FECHA_EVALUACION BETWEEN '$FECHA1' AND '$FECHA2'".$lol)) {

		while($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $myArray[] = $row;
    	}
    	echo json_encode($myArray,JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    	$result -> close();

    }


$conexion -> close();
?>