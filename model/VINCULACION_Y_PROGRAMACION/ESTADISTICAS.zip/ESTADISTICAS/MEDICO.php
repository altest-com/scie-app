<?php
header("Content-type: text/html; charset=utf8");
header('Content-type:application/json');
require("../../conexion.php"); 

$FECHA1 = $_REQUEST['FECHA1']." 00:00:01";
$FECHA2 = $_REQUEST['FECHA2']." 23:59:59";
$lol = $_REQUEST['lol'];


$conexion->set_charset("utf8");



	if ($result = $conexion->query("SELECT CA.PRIMER_NOMBRE,CA.SEGUNDO_NOMBRE,CA.PRIMER_APELLIDO,CA.SEGUNDO_APELLIDO, CA.CURP FROM medico_clinica08 C8 INNER JOIN medico_clinica10 C10 ON C8.ID_CANDIDATO = C10.ID_CANDIDATO AND C8.ID_EVALUACION = C10.ID_EVALUACION INNER JOIN medico_clinica06 C6 ON C8.ID_CANDIDATO = C6.ID_CANDIDATO AND C8.ID_EVALUACION = C6.ID_EVALUACION INNER JOIN  evaluacion EV ON C8.ID_EVALUACION = EV.ID_EVALUACION INNER JOIN candidatos CA ON CA.ID_CANDIDATO = EV.ID_CANDIDATO LEFT JOIN reportes R ON R.ID_CANDIDATO = C8.ID_CANDIDATO AND R.ID_EVALUACION = C8.ID_EVALUACION LEFT JOIN historia_datos_generales H ON C8.ID_CANDIDATO = H.ID_CANDIDATO AND C8.ID_EVALUACION = H.ID_EVALUACION WHERE R.DEPARTAMENTO_ORIGEN = 'MÉDICO' AND EV.FECHA_EXAMEN_MEDICO BETWEEN '$FECHA1' AND '$FECHA2'".$lol)) {

		while($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $myArray[] = $row;
    	}
    	echo json_encode($myArray,JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    	$result -> close();

    }


$conexion -> close();
?>